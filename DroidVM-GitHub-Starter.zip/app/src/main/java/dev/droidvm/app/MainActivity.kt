package dev.droidvm.app

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    private var onZipChosen: ((Uri?) -> Unit)? = null
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onZipChosen?.invoke(uri)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var selected by remember { mutableStateOf("No firmware imported") }
            var status by remember { mutableStateOf("Import a ROM ZIP to inspect it.") }
            var ram by remember { mutableFloatStateOf(1536f) }
            var cpus by remember { mutableFloatStateOf(2f) }
            var engine by remember { mutableStateOf("crosvm / KVM (experimental)") }
            var roms by remember { mutableStateOf(filesDir.resolve("roms").listFiles()?.toList() ?: emptyList()) }
            MaterialTheme(colorScheme = if (android.os.Build.VERSION.SDK_INT >= 31) dynamicLightColorScheme(this) else lightColorScheme()) {
                Scaffold(topBar = { TopAppBar(title = { Text("DroidVM") }, actions = {
                    IconButton(onClick = { status = "DroidVM 0.1.0 · emulator backend is not integrated yet." }) { Icon(Icons.Default.Info, "Info") }
                }) }) { padding ->
                    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            Card(shape = RoundedCornerShape(28.dp)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Virtual Android", style = MaterialTheme.typography.headlineSmall)
                                    Text("Manage firmware ZIPs and virtual-device settings.", style = MaterialTheme.typography.bodyMedium)
                                    Button(onClick = {
                                        onZipChosen = { uri ->
                                            if (uri != null) {
                                                try {
                                                    val out = File(filesDir, "roms").apply { mkdirs() }
                                                    val name = "firmware_${System.currentTimeMillis()}"
                                                    val dest = File(out, name).apply { mkdirs() }
                                                    contentResolver.openInputStream(uri)?.use { input ->
                                                        ZipInputStream(input).use { zip ->
                                                            var entry = zip.nextEntry
                                                            var count = 0
                                                            while (entry != null && count < 10000) {
                                                                val target = File(dest, entry.name).canonicalFile
                                                                require(target.path.startsWith(dest.canonicalPath + File.separator) || target == dest)
                                                                if (entry.isDirectory) target.mkdirs() else {
                                                                    target.parentFile?.mkdirs()
                                                                    target.outputStream().use { output -> zip.copyTo(output) }
                                                                }
                                                                zip.closeEntry(); entry = zip.nextEntry; count++
                                                            }
                                                        }
                                                    } ?: error("Cannot open selected file")
                                                    selected = name
                                                    roms = out.listFiles()?.toList() ?: emptyList()
                                                    status = "ZIP extracted into app storage. This does not flash or boot it."
                                                } catch (e: Exception) { status = "Import failed: ${e.message}" }
                                            }
                                        }
                                        picker.launch(arrayOf("application/zip", "application/octet-stream"))
                                    }, modifier = Modifier.fillMaxWidth()) {
                                        Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Import firmware ZIP")
                                    }
                                    Text(status, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        item { Text("Virtual device settings", style = MaterialTheme.typography.titleLarge) }
                        item {
                            Card(shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("RAM: ${ram.toInt()} MB")
                                    Slider(value = ram, onValueChange = { ram = it }, valueRange = 512f..3072f, steps = 9)
                                    Text("CPU cores: ${cpus.toInt()}")
                                    Slider(value = cpus, onValueChange = { cpus = it }, valueRange = 1f..4f, steps = 2)
                                    Text("Graphics: software / host (planned)")
                                    Text("Engine")
                                    listOf("crosvm / KVM (experimental)", "Fallback backend (not available)").forEach {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            RadioButton(selected = engine == it, onClick = { engine = it })
                                            Text(it)
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Card(shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Boot virtual device", style = MaterialTheme.typography.titleMedium)
                                    Text("The VM engine, Android guest boot, virtual recovery, guest root and LSPosed are not implemented in this starter build.", style = MaterialTheme.typography.bodyMedium)
                                    Button(onClick = { status = "Boot unavailable: crosvm/KVM backend is not integrated." }, enabled = false, modifier = Modifier.fillMaxWidth()) {
                                        Icon(Icons.Default.PowerSettingsNew, null); Spacer(Modifier.width(8.dp)); Text("Start VM")
                                    }
                                }
                            }
                        }
                        item { Text("Imported archives", style = MaterialTheme.typography.titleLarge) }
                        if (roms.isEmpty()) item { Text("No ZIP archives imported yet.") }
                        items(roms) { file ->
                            ListItem(headlineContent = { Text(file.name) }, supportingContent = { Text("Extracted archive contents") }, leadingContent = { Icon(Icons.Default.Archive, null) })
                        }
                        item { Text("Selected: $selected", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
    }
}
